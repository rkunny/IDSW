import mysql.connector as ms
import sys
from flask import Flask
from flask_cors import CORS
from flask_restful import Resource, Api
import json
from flask_jsonpify import jsonify
import datetime
import request


try:
    conn = ms.connect(
        host="localhost",
        user="rammohan",
        passwd="letmein",
        database="idsw")
except ms.Error as e:
    print("Database Connection Not Established. Check credentials")
    sys.exit(1)

cursor = conn.cursor()
app = Flask(__name__)
api = Api(app)
CORS(app)


class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            encoded_object = list(obj.timetuple())[0:6]
        else:
            encoded_object = json.JSONEncoder.default(self, obj)
        return encoded_object


class Forecast(Resource):
    def get(self):
        cursor.execute(
            "select fh.client_name 'CLIENT', fh.project_name 'PROJECT', pp.employee_name 'EMPLOYEE', "
            "pp.location 'LOCATION', pp.team_name 'TEAM', sp.sigma_num 'SIGMA', "
            "s.business_unit 'BUSINESS UNIT', fh.adj_unit 'PLANNED HOURS', "
            "date_format(fh.forecast_date, '%Y/%m/%d') forecast_date "
            "from forecast_hrs fh "
            "join people pp on pp.employee_name = fh.employee_name "
            "join sigma_project_mapping sp on sp.planview_project_name = fh.project_name "
            "join sigma s on s.sigma_num = sp.sigma_num ")

        result = {'forecast':[dict(zip(tuple(cursor.column_names),i)) for i in cursor]}
        return jsonify(result)


class Ytd(Resource):
    def get(self):
        cursor.execute("select tl.work_date, pp.employee_name, sum(tl.time_logged) from time_logging tl "
                       "join people pp on pp.employee_id = tl.employee_id "
                       "where year(tl.work_date) = year(curdate()) and tl.planview_project_id not in (0, 1, 2, 3) "
                       "group by pp.employee_name")

        result = {'ytd_hrs': [dict(zip(tuple(cursor.column_names), i)) for i in cursor]}
        # return json.dumps(result, sort_keys=True, default=str)
        return json.dumps(result, sort_keys=True, default=str, separators=None)


class StandardHours(Resource):
    def get(self):
        cursor.execute("select tl.work_date, pp.employee_name, tl.work_description, tl.time_logged "
                       "from time_logging tl "
                       "join people pp on pp.employee_id = tl.employee_id "
                       "where year(tl.work_date) = year(curdate()) and tl.planview_project_id in (0)")

        result = {'std_act_hrs': [dict(zip(tuple(cursor.column_names), i)) for i in cursor]}
        return jsonify(result)


class BusinessUnit(Resource):
    # @app.route("/")
    def get(self):
        # self.set_header
        cursor.execute("select bu_name, value_text from business_unit")

        result = {'business_unit':[dict(zip(tuple(cursor.column_names),i)) for i in cursor]}
        return jsonify(result)


class Products(Resource):
    def get(self):
        cursor.execute("select product_name, product_value, p_business_unit from product")

        result = {'products':[dict(zip(tuple(cursor.column_names),i)) for i in cursor]}
        return jsonify(result)


class BillableType(Resource):
    def get(self):
        cursor.execute("select type_of_billable, billable_value from billable_type")

        result = {'billable_type':[dict(zip(tuple(cursor.column_names),i)) for i in cursor]}
        return jsonify(result)


api.add_resource(Forecast,'/forecast')
api.add_resource(Ytd,'/ytd_hrs')
api.add_resource(StandardHours,'/std_act_hrs')
api.add_resource(BusinessUnit,'/business_unit')
api.add_resource(Products,'/products')
# api.add_resource(BillableType,'/billable_type')

if __name__ == '__main__':
    app.run(port='5002')
