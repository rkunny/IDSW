 /*Mobile nav*/
    /*created a variable called 'nav' for all the contents within main nav*/
    /*On clicking on the icon, it will show and close the content of main nav*/
    $('.js--nav-icon').click(function(){
       var nav = $('.js--main-nav'):
       nav.slideToggle(200);
    });

$(document).ready(function () {
    $('#menu')
       .append($('<ul/>')
          .append('<li>something</li>')
          .append('<li>something</li>')
          .append('<li>something</li>')
          .append('<li>something</li>')
          .append('<li>something</li>')
          .append('<li>something</li>')
          .append('<li>something</li>')
          .append('<li>something</li>')
          .append('<li>something</li>')
          .append('<li>something</li>')
       );
}