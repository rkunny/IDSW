$(document).ready(function () {
    
    $('#main-content').addClass('js--content-on-slideout');
    $('#arrow-forward').addClass('js--slideout-icon-hide');
    $('#arrow-forward-for-single-content').addClass('js--slideout-icon-hide');
    $('#idsw-sub').addClass('js--idsw-sub-hide');
    $('#forecast-by-employee').addClass('js--btn');
    $('#forecast').addClass('js--topic');
        
    $('.slidein-icon').click(function () {
        $('#main-content').removeClass('js--content-on-slideout');
        $('#main-content').addClass('js--content-on-slidein');
        $('#arrow-back').remove('a');
        $('#arrow-back').addClass('js--slidein-icon-hide');
        $('.main-topic').addClass('js--main-topic-hide');
        $('.topic-icon').addClass('.topic-icon-centered')
        $('#arrow-forward').addClass('js--slideout-icon-unhide');
        $('#table-area').addClass('js--data-table')
        $('#chart-area').addClass('js--chart-area')
    });
    
    $('.slideout-icon').click(function () {
        $('#main-content').addClass('js--content-on-slideout');
        $('#main-content').removeClass('js--content-on-slidein');
        $('#arrow-back').removeClass('js--slidein-icon-hide');
        $('#arrow-back').add('a');
        $('#arrow-forward').removeClass('js--slideout-icon-unhide');
        $('.main-topic').removeClass('js--main-topic-hide');
        $('#table-area').removeClass('js--data-table');
        $('#chart-area').removeClass('js--chart-area');
    });
        
    $('#expand-table').click(function(){
        $('#chart-area').addClass('js--chart-area-display');
        $('#main-content').addClass('js--content-on-slidein');
        $('#arrow-back').remove('a');
        $('#arrow-back').addClass('js--slidein-icon-hide');
        $('#arrow-forward').addClass('js--slideout-icon-unhide');
        $('.main-topic').addClass('js--main-topic-hide');
        $('.topic-icon').addClass('.topic-icon-centered');
        $('.data-table').addClass('js--expand-table');
        $('#table-close').addClass('table-close-remove');
        $('#expand-table').addClass('js--remove-on-expand');
        $('#contract-table').removeClass('contract-table');
        $('#the-tables').addClass('js--the-tables-on-expand');
    })
    
//    $('.js--slideout-table-area-resize').click(function () {
//        $('#main-content').addClass('js--content-on-slideout');
//        $('#main-content').removeClass('js--content-on-slidein');
//        $('#arrow-back').removeClass('js--slidein-icon-hide');
//        $('#arrow-forward').removeClass('js--slideout-icon-unhide');
//        $('#arrow-back').add('a');
//        $('.main-topic').removeClass('js--main-topic-hide');
//        $('.data-table').addClass('js--expand-table-resize');
//    });
    
    $('#contract-table').click(function(){
        $('#chart-area').removeClass('js--chart-area-display');
        $('#main-content').removeClass('js--content-on-slidein');
        $('#arrow-back').add('a');
        $('#arrow-back').removeClass('js--slidein-icon-hide');
        $('.main-topic').removeClass('js--main-topic-hide');
        $('.topic-icon').removeClass('.topic-icon-centered')
        $('#arrow-forward').removeClass('js--slideout-icon-unhide');
        $('.data-table').removeClass('js--expand-table');
        $('#table-close').removeClass('table-close-remove');
        $('#expand-table').removeClass('js--remove-on-expand');
        $('#contract-table').addClass('contract-table');
        $('#the-tables').removeClass('js--the-tables-on-expand');

    })
    
    $('#expand-chart').click(function(){
        $('#table-area').addClass('js--table-area-display');
        $('#main-content').addClass('js--content-on-slidein');
        $('#arrow-back').remove('a');
        $('#arrow-back').addClass('js--slidein-icon-hide');
        $('.main-topic').addClass('js--main-topic-hide');
        $('.topic-icon').addClass('.topic-icon-centered');
        $('#arrow-forward').addClass('js--slideout-icon-unhide');
        $('.chart-area').addClass('js--expand-chart');
        $('#table-close').addClass('table-close-remove');
        $('#expand-chart').addClass('js--remove-on-expand');
        $('#contract-chart').removeClass('contract-chart');
    })
    
    $('#contract-chart').click(function(){
        $('#table-area').removeClass('js--table-area-display');
        $('#main-content').removeClass('js--content-on-slidein');
        $('#arrow-back').add('a');
        $('#arrow-back').removeClass('js--slidein-icon-hide');
        $('.main-topic').removeClass('js--main-topic-hide');
        $('.topic-icon').removeClass('.topic-icon-centered');
        $('#arrow-forward').removeClass('js--slideout-icon-unhide');
        $('.chart-area').removeClass('js--expand-chart');
        $('#table-close').removeClass('table-close-remove');
        $('#expand-chart').removeClass('js--remove-on-expand');
        $('#contract-chart').addClass('contract-chart');
    })
    
    $('.click-for-idsw-sub').click(function(){
        $('#forecast-sub').addClass('js--forecast-sub-hide');
        $('#idsw-sub').removeClass('js--idsw-sub-hide');
    })
    
    $('.click-for-forecast-sub').click(function(){
        $('#forecast-sub').removeClass('js--forecast-sub-hide');
        $('#idsw-sub').addClass('js--idsw-sub-hide');
    })
});