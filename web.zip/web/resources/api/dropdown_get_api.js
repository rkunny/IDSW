let buss_unit_option = document.getElementById('buss-unit');
buss_unit_option.length = 0;

let defaultBuOption = document.createElement('option');
defaultBuOption.text = 'All Business Units';

buss_unit_option.add(defaultBuOption);
buss_unit_option.selectedIndex = 0;

var request = new XMLHttpRequest();

request.open('GET', 'http://localhost:5002/business_unit', true);

request.onload = function () {
    const data = JSON.parse(this.responseText);
    let option;
    for (let i=0; i < data.business_unit.length; i++){
        option = document.createElement('option');
        option.text = data.business_unit[i].bu_name;
        option.value = data.business_unit[i].value_text;
        buss_unit_option.add(option);
    }
}
request.send();

let product_list_option = document.getElementById('product');
product_list_option.length = 0;

let defaultProductOption = document.createElement('option');
defaultProductOption.text = 'All Products';

product_list_option.add(defaultProductOption);
product_list_option.selectedIndex = 0;

var request = new XMLHttpRequest();

request.open('GET', 'http://localhost:5002/products', true);

request.onload = function () {
    const data = JSON.parse(this.responseText);
    let option;
    for (let i=0; i < data.products.length; i++){
        option = document.createElement('option');
        option.text = data.products[i].product_name;
        option.value = data.products[i].product_value;
        product_list_option.add(option);
    }
}
request.send();


let report_type_option = document.getElementById('report-type');
report_type_option.length = 0;

let defaultReportTypeOption = document.createElement('option');
defaultReportTypeOption.text = 'All';

report_type_option.add(defaultReportTypeOption);
report_type_option.selectedIndex = 0;

var request = new XMLHttpRequest();

request.open('GET', 'http://localhost:5002/billable_type', true);

request.onload = function () {
    const data = JSON.parse(this.responseText);
    let option;
    for (let i=0; i < data.billable_type.length; i++){
        option = document.createElement('option');
        option.text = data.billable_type[i].type_of_billable;
        option.value = data.billable_type[i].billable_value;
        report_type_option.add(option);
    }
}
request.send();