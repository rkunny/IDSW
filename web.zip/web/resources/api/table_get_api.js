function CreateTableFromJSON() {
        var myBooks = [
            {
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Bhat, Sahil",
"LOCATION": "GSC",
"PLANNED HOURS": 5,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Singh, Meghna",
"LOCATION": "GSC",
"PLANNED HOURS": 15,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Singh, Meghna",
"LOCATION": "GSC",
"PLANNED HOURS": 15,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory WS3 Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Kesavan, Unny Rammohan",
"LOCATION": "GSC",
"PLANNED HOURS": 20,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Harkal, Tattyasaheb",
"LOCATION": "GSC",
"PLANNED HOURS": 25,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Kumar, Manish",
"LOCATION": "GSC",
"PLANNED HOURS": 35,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Mittal, Sheetal",
"LOCATION": "GSC",
"PLANNED HOURS": 50,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory WS3 Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Yadav, Suryakant",
"LOCATION": "GSC",
"PLANNED HOURS": 55,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory WS3 Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Kale, Surabhi",
"LOCATION": "GSC",
"PLANNED HOURS": 60,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory WS3 Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Ligory, Sandra",
"LOCATION": "GSC",
"PLANNED HOURS": 65,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Iqbal, Shahid Syed",
"LOCATION": "GSC",
"PLANNED HOURS": 70,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Mohan, Sindhu",
"LOCATION": "GSC",
"PLANNED HOURS": 0,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Achary, Ramesh",
"LOCATION": "GSC",
"PLANNED HOURS": 45,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Tripathi, Anant",
"LOCATION": "GSC",
"PLANNED HOURS": 55,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Parida, Kaberi",
"LOCATION": "GSC",
"PLANNED HOURS": 60,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Kale, Snehal",
"LOCATION": "GSC",
"PLANNED HOURS": 65,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Tirupati, Suparna",
"LOCATION": "GSC",
"PLANNED HOURS": 70,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Ram, Lekh",
"LOCATION": "GSC",
"PLANNED HOURS": 75,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/01/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Bhat, Sahil",
"LOCATION": "GSC",
"PLANNED HOURS": 0,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Singh, Meghna",
"LOCATION": "GSC",
"PLANNED HOURS": 48,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Singh, Meghna",
"LOCATION": "GSC",
"PLANNED HOURS": 48,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory WS3 Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Kesavan, Unny Rammohan",
"LOCATION": "GSC",
"PLANNED HOURS": 4,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Harkal, Tattyasaheb",
"LOCATION": "GSC",
"PLANNED HOURS": 1,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Kumar, Manish",
"LOCATION": "GSC",
"PLANNED HOURS": 19,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Mittal, Sheetal",
"LOCATION": "GSC",
"PLANNED HOURS": 26,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory WS3 Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Ligory, Sandra",
"LOCATION": "GSC",
"PLANNED HOURS": 41,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Iqbal, Shahid Syed",
"LOCATION": "GSC",
"PLANNED HOURS": 30,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Mohan, Sindhu",
"LOCATION": "GSC",
"PLANNED HOURS": 0,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Achary, Ramesh",
"LOCATION": "GSC",
"PLANNED HOURS": 21,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Tripathi, Anant",
"LOCATION": "GSC",
"PLANNED HOURS": 31,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Parida, Kaberi",
"LOCATION": "GSC",
"PLANNED HOURS": 36,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Kale, Snehal",
"LOCATION": "GSC",
"PLANNED HOURS": 25,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Tirupati, Suparna",
"LOCATION": "GSC",
"PLANNED HOURS": 46,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Ram, Lekh",
"LOCATION": "GSC",
"PLANNED HOURS": 59,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/02/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Bhat, Sahil",
"LOCATION": "GSC",
"PLANNED HOURS": 112,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/07/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Singh, Meghna",
"LOCATION": "GSC",
"PLANNED HOURS": 104,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/07/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Singh, Meghna",
"LOCATION": "GSC",
"PLANNED HOURS": 104,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory WS3 Quality Assurance",
"forecast_date": "2019/07/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Kesavan, Unny Rammohan",
"LOCATION": "GSC",
"PLANNED HOURS": 120,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/07/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Harkal, Tattyasaheb",
"LOCATION": "GSC",
"PLANNED HOURS": 120,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/07/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Kumar, Manish",
"LOCATION": "GSC",
"PLANNED HOURS": 112,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/07/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Mittal, Sheetal",
"LOCATION": "GSC",
"PLANNED HOURS": 120,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory WS3 Quality Assurance",
"forecast_date": "2019/07/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Ligory, Sandra",
"LOCATION": "GSC",
"PLANNED HOURS": 96,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/07/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Iqbal, Shahid Syed",
"LOCATION": "GSC",
"PLANNED HOURS": 112,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/07/01"
},
{
"BUSINESS UNIT": "Advisory",
"CLIENT": "Internal",
"EMPLOYEE": "Mohan, Sindhu",
"LOCATION": "GSC",
"PLANNED HOURS": 136,
"PROJECT": "IV Wealth IT, Security and Upgrade Projects [CAP]",
"SIGMA": "19-0040-01-01",
"TEAM": "Prod Advisory IV Quality Assurance",
"forecast_date": "2019/07/01"
}
        ]

        // EXTRACT VALUE FOR HTML HEADER. 
        // ('adj_unit', 'business_unit', 'client_name', 'employee_name','forecast_date', 'location', 'project_name','sigma_num', 'team_name
        var col = [];
        for (var i = 0; i < myBooks.length; i++) {
            for (var key in myBooks[i]) {
                if (col.indexOf(key) === -1) {
                    col.push(key);
                }
            }
        }

        // CREATE DYNAMIC TABLE.
        var table = document.getElementById("the-tables");

        // CREATE HTML TABLE HEADER ROW USING THE EXTRACTED HEADERS ABOVE.

        var tr = table.insertRow(-1);                   // TABLE ROW.

        for (var i = 0; i < col.length; i++) {
            var th = document.createElement("th");      // TABLE HEADER.
            th.innerHTML = col[i];
            tr.appendChild(th);
        }

        // ADD JSON DATA TO THE TABLE AS ROWS.
        for (var i = 0; i < myBooks.length; i++) {

            tr = table.insertRow(-1);

            for (var j = 0; j < col.length; j++) {
                var tabCell = tr.insertCell(-1);
                tabCell.innerHTML = myBooks[i][col[j]];
            }
        }

        // FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
        var divContainer = document.getElementById("showData");
        divContainer.innerHTML = "";
        divContainer.appendChild(table);
    }